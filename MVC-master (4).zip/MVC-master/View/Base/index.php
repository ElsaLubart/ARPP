<section class="py-0" id="header"> <!---Page staitique rien de dynamique pas d'appel aà la base de données pour récupérer des information--->  
    <div class="bg-holder d-none d-md-block"
        style="background-image:url(<?=BU?>/public/images/question.jpg);background-position:right top;background-size:60%;">
    </div>

    <div class="bg-holder d-md-none"
        style="background-image:url(<?=BU?>/public/images/hero-bg.png);background-position:right top;background-size:contain;">
    </div>

    <div class="container"> <!---Acceuil--->
        <div class="row align-items-center min-vh-75 min-vh-lg-100">
            <div class="col-md-7 col-lg-6 col-xxl-5 py-6 text-sm-start text-center">
                <h1 class="mt-6 mb-sm-4 fw-semi-bold lh-sm fs-4 fs-lg-5 fs-xl-6">Association pour la Recherche en Pédopsychiatrie et Psychologie</h1>
                <p class="mb-4 fs-1">ARPP existe depuis mai 2003.Ses membres sont des chercheurs qui mènent des projets de recherches et/ou des actions de formation spécialisée dans les champs de pédopsychiatrie ou de psychologie.</p>
                <button class="btn btn-lg btn-light bg-gradient order-0" ><a href = "<?=Url::link('Formations/index');?>">Découvrir nos formations!</a></button>
               
            </div>
        </div>
    </div>
</section>
<section class="py-5" id="who"><!---Partie Qui sommesnous présentation---->
    <div class="bg-holder d-none d-sm-block"
        style="background-image:url(<?=BU?>/public/images/bg.png);background-position:top left;background-size:225px 755px;margin-top:-17.5rem;">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-9 mx-auto text-center mb-3">
                <h5 class="fw-bold fs-3 fs-lg-5 lh-sm mb-3">Qui sommes nous?</h5>
                <p class="mb-5">ARPP organise des evenements et formations et apporte son soutien aux projets de recherches </p>
            </div>
        </div>
        <div class="row flex-center h-100">
            <div class="col-xl-9">
                <div class="row">
                    <div class="col-md-4 mb-5">
                        <div class="card h-100 shadow px-4 px-md-2 px-lg-3 card-span pt-6">
                            <div class="text-center text-md-start card-hover"><img class="ps-3 icons"
                                    src="<?=BU?>/public/images/logo.png" height="60" alt="" />
                                <div class="card-body">
                                    <h6 class="fw-bold fs-1 heading-color">Soutien aux projets de recherches</h6>
                                    <p class="mt-3 mb-md-0 mb-lg-2">Exemple : 
                                    <br/>- Les enfants à haut potentiel en difficulté 
                                    
                                    <br/>- Le développement d'outils de détection de la créativité chez l'enfant
                                    <br/>- nouvelle pratiques en pédopsychiatrie face à la crise sanitaire COVID-19</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-5">
                        <div class="card h-100 shadow px-4 px-md-2 px-lg-3 card-span pt-6">
                            <div class="text-center text-md-start card-hover"><img class="ps-3 icons"
                                    src="<?=BU?>/public/images/formation.svg" height="60" alt="" />
                                <div class="card-body">
                                    <h6 class="fw-bold fs-1 heading-color">Formations spécialisées</h6>
                                    <p class="mt-3 mb-md-0 mb-lg-2">Exemples :
                                    <br/>- Les enfants à haut potentiel en difficulté
                                    <br/>- La détection du potentiel créatif
                                    <br>- La créativité en contexte thérapeutique</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-5">
                        <div class="card h-100 shadow px-4 px-md-2 px-lg-3 card-span pt-6">
                            <div class="text-center text-md-start card-hover"><img class="ps-3 icons"
                                    src="<?=BU?>/public/images/colloquia.svg" height="60" alt="" />
                                <div class="card-body">
                                    <h6 class="fw-bold fs-1 heading-color">Colloques et des événements ponctuels</h6>
                                    <p class="mt-3 mb-md-0 mb-lg-2">Exemples :

                                        <br/>- Colloque nationale concernant les enfants à haut potentiel en difficulté
                                        <br/>- Cycle de séminaires en pédopsychiatre </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="py-0" id="contact"><!---Page Contact---->
    <div class="bg-holder"
        style="background-image:url(<?=BU?>/public/images/how-it-works.png);background-position:center bottom;background-size:cover;">
    </div>
    <div class="container-lg">
        <div class="row justify-content-center">
            <div class="col-sm-8 col-md-9 col-xl-5 text-center pt-8">
                <h5 class="fw-bold fs-3 fs-xxl-5 lh-sm mb-3 text-white">Contactez-nous</h5>
                <p class="mb-5 text-white">Une question? Vous êtes au bon endroit.</p>
                <div class="form-group mb-4 text-center" color="light">
              
                <button class="btn btn-lg btn-light bg-gradient order-0" ><a href = "mailto:arppmessagerie@gmail.com?subject = Question = content">Envoyer mon message</a></button>
                
             </div>  
            </div>
            
             <!----------Bas de page avec la boîte information ------------->
            <div class="col-md-4 mb-5">
                        <div class="card h-100 shadow px-4 px-md-2 px-lg-3 card-span pt-6">
                            <div class="text-center text-md-start card-hover"><img class="ps-3 icons"
                                    src="<?=BU?>/public/images/Asso.png" height="60" alt="" />
                                <div class="card-body">
                                    <h6 class="fw-bold fs-1 heading-color">Informations ARPP</h6>
                                    <p class="mt-3 mb-md-0 mb-lg-2"><b>Parution dans le Journal officiel </b><br/> le 3 mai 2003<br/><b>APE</b><br/> 913E<br/><b>SIRET</b><br/>450 404 892 00017<br/><b>Mail</b><br/>arppmessagerie@gmail.com<br/><b>Siège social</b><br/>90 avenue du maine , 75014 Paris<br/><b>Numéro d'organisme de formation</b><br/> 53350874535</p> </p>
                                </div>
                            </div>
                        </div>       
              
            </div>
        </div>
    </div>
</section>
<script src="<?=BU?>/public/js/home/home.js"></script>
