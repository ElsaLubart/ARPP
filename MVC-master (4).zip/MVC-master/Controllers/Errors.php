<?php
// PAS DE VUE A PART L'INDEX. On a même forcer index dans l'erreur index. Regroupement de tout les autres erreurs, erreur interne du serveur
class Errors extends Controlleur {
    public function index(){ 
        $this->request->controlleur = "Errors";
        $this->request->action = "index";
        header("HTTP/1.0 500 Internal Server Error"); 
        $vars = array(); 
        $vars["title"] = "Ooops ! j'ai tout Cassé !";
        $vars["subTitle"] = "500 Internal Server Error"; 

        $this->render($vars);//Possibilité de rendre : appelle de la méthode render
    }

    //Erreur 404 correspond à page introuvalle 
    //localhost/projet.. après c'est le controlleur après c'est l'action après les paramètres. 
    //Une page est définit par le controlleur, l'action du controlleur et les paramètres à passer au controlleur. Si il manque une donnée il va donné page introuvable

    public function e404(){
        $this->request->controlleur = "Errors";
        $this->request->action = "index"; //rend vue d'erreur 
        header("HTTP/1.0 404 Not Found");//header() permet de spécifier l'en-tête HTTP string lors de l'envoi des fichiers HTML
        $vars = array();
        $vars["title"] = "404";
        $vars["subTitle"] = "404 Not Found"; 
        $this->render($vars);
    }

}