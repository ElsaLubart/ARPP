<?php
//Gère les différentes pages statiques et authentification 
class Base extends Controlleur { //Notion d'heritage la base hérite du controlleur

    function index(){// Appelle la fonction index 

    }

    public function login(){//Fonction login pour se connecter. Elle permet 
        //
        $s = Session::loadSession(); //fonction définit dans session.php pour développer la session 
        if($s->loginVerification())$this->redirect("Base/index");//si login est bien verifier on est redirigé vers la base 
        if(!$this->request->data ) return;
        $HashedPass = "8cb2237d0679ca88db6464eac60da96345513964";
        $pass = $this->request->data->password;//variable mot de passe 
        $login = $this->request->data->login;//varaible identifiant 

        if(sha1($pass) === $HashedPass && $login==="Admin"){//Si le mot de passe et l'identifiant sont correct connexion de l'admin 
            $data = array();
            unset($this->request->data->password);
            foreach($this->request->data as $k=>$v) 
                $data[$k] = $v;
            $s->setLoginSession($data);//Définit dans Session pour la session de l'admin 
        }else{
            $s->setFlash("Authentification échouée !!","danger");//Erreur d'authentification avec un message flash voir fonction SetFlash définit dans Session
            return;
        }
        $this->redirect("Base/index");
        die();



    }

    public function logout(){//Permet de réaliser la déconnexion 
        //
        $s = Session::loadSession();
        if($s->loginVerification()){
            $s->disconnect();
        }
        $this->redirect("Base/index");
    }
    
    public function download($controller, $id, $fichier){//Permet de réaliser le télechargement 
        $file = UPLOADS.DS."{$fichier}";

        if (file_exists($file)) {//Si le fichier existe Pour telacharger un fichier il faut informaer le navigateur 
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');//stream c'est la trame de bit
            header('Content-Disposition: attachment; filename="'.basename($file).'"');//nom
            header('Expires: 0');//Valide jusqu'à quand 
            header('Cache-Control: must-revalidate');//toujours valider la requête est-ce qu'on va sauvagerder le fichier non
            header('Pragma: public');//requête publique 
            header('Content-Length: ' . filesize($file));//taille du fichier 
            readfile($file);
        }

        switch ($controller) {
            case 'F'://cas de formation /
            $this->redirect("Formations/details/".$id);
                break;
            
            case 'E'://cas de EVNT /
                $this->redirect("Evenements/details/".$id);
                break;
            
            default://par défaut on est redirigé vers la base du constructeur 
                $this->redirect("Base");
                break;
        }
    }

    public function FAQ(){ //Fonction pour FAQ pour rendre FAQ
        $model = new Model("faq","IdQuestion");//Nouveau model avec les deux paramètres 
        $model->getAll();//Récupération 
        $this->model = $model;
    }

}