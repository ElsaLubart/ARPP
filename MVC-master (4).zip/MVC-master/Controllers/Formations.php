<?php

class Formations extends Controlleur {
    public function index(){ //Methode index 
       
        $model = new Model("formation","IdFormation");//Instance le modèle et table formation qu'on veut  interroger
        $model->getAll();  //Récupère tout les enregistrement de la table souhaité 
        $this->model = $model; //Injecte le modèle dans le controlleur toujours accessible 
        if($this->request->data){//Si dans la requête on a des données passé- pas seulement affiché la liste des formations mais manipulation 
            //insérer ou modifier. Cas d'index juste insertion. Si on a des données on les traite après sinon rien
        
        }else{
            return;
        }
        $data = array();//Tratement des données pour les passer à la méthode save- mise en forme clés valeur 
        
        foreach ($this->request->data as $k=>$v){ 
            $data[$k] = $v;
        }
        $data["Duree"] = intval($this->request->data->jours)*24 + intval($this->request->data->heurs);
        unset($data["jours"]);
        unset($data["heurs"]);
        
        if($model->save($data)) {
            $s=Session::loadSession();
            $s->setFlash("La formation a vien été crée !!");
            $this->redirect("Formations/details/".$model->lastInsert);
            die();
        }

    }

    public function details($id){
        
        $model = new Model("formation","IdFormation");//On instance le modèle 
        $model->getOneById($id);//Récupère l'info par l'ID
        $this->model = $model;//Injecte le modèle dans le contrôleur
        if(count($model->list)<= 0){
            //si on trouve  pas une formation on provoque une erreur type page introuvable
            $this->request->Errors->e404(); 
            die();
        }
        $files =  new Model("fichier","id");//Modèle pour les fichiers 
        $files->exec("select * from fichier where formation = {$id}");//Appelle à la méthode exec car jointure implicite pour recup les fichiers 
        $model->files = $files->list; //Liste des fichiers //On les injecte dans le modéle de formation
        $members = new Model("inscritf","id");//Pareille mais avec membres inscrit 
        $members->exec("select * from inscritf join membre on inscritf.IdMembre = membre.IdMembre where inscritf.IdFormation = {$id}");//Jointure sql explicite avec exec 
        $model->members = $members->list;//résulats injecté dans le modèle formation 
        $model->list[0]->NbPersonneInscrit = count($members->list);

        if($this->request->data){//Si on a des données on veut modifié la formation 
       
        }else{
            return;
        }
        $data = array();//Tableau vide préparer les donnes pour lethode save 
        
        foreach ($this->request->data as $k=>$v){
            $data[$k] = $v;
        }
        $data["Duree"] = intval($this->request->data->jours)*24 + intval($this->request->data->heurs);
        unset($data["jours"]);
        unset($data["heurs"]);

        if($model->save($data)){
            $s=Session::loadSession();
            $s->setFlash("La formation a vien été modifiée !!");
            $this->redirect("Formations/details/".$id);
        }
        die();

    }

    public function delete($id){//supprimer formation 
        if(!isset($id)) die("il faut un ID");
        $model = new Model("formation","IdFormation");
        $model->delete($id); 
        $this->redirect("Formations/index");
    }

    public function uploadFile(){//Télacharger des fichiers 
        $model = new Model("fichier","id");
        $file = $this->request->data->file;
        $path = $this->validateFileToUpload($file);
        $formation = $this->request->data->formation;
        if($path){
            extract($path);
            $data = array();
            $data["name"] = $name;
            $data["path"] = $to;
            $data["formation"] = $formation;
            move_uploaded_file($from, UPLOADS.DS.$to);//Déplacer un fichier d'un endroit à un autre 
            if($model->save($data)){
                $s=Session::loadSession();
                $s->setFlash("Le document a bien été téléchargé");
            };

        }
        $this->redirect("Formations/details/".$formation);
    }

    public function register (){//S'inscrire gere inscription (rend pas de vue)On instancie le modèle on récupère info....
        $membre = new Model("membre","IdMembre");
        $linkToFormation = new Model("inscritf","id");
        $email = $this->request->data->Mail;
        $membre->exec("select * from membre where Mail='{$email}'");
        $IdMembre = null;
        $IdFormation = $this->request->data->IdFormation;
        unset($this->request->data->IdFormation);
        $exist = false;
        if(count($membre->list)>0){
            $IdMembre = $membre->list[0]->IdMembre;
            $exist = true;
            if($IdFormation){
                $linkToFormation->exec("select * from inscritf where IdMembre = '{$IdMembre}' and IdFormation='{$IdFormation}'");
                if(count($linkToFormation->list)>0){
                    $s = Session::loadSession();
                    $s->setFlash("Vous êtes déjà inscrit dans cette formation","info");//pas possible de s'inscrire plusieurs fois
                    $this->redirect("Formations/details/{$IdFormation}");
                    die();
                }
                
            }else{
                $this->redirect("Formations/details/{$IdFormation}");//Rediroger vers ecran detailsi qqch ne passe pas 
                die();
            }
        }
        $data = array();
        $dataInscrit = array();
        foreach ($this->request->data as $k=>$v){
            $partsKey = explode("_",$k);
            if(count($partsKey)<=1)
                $data[$k] = $v;
            else $dataInscrit[end($partsKey)] = $v;
        }
        
        if(!filter_var($data["Mail"],FILTER_VALIDATE_EMAIL)){//Contrôle sur la mail si pas valide on rejette (bon endroit methode validate classe modèle) 
            $s = Session::loadSession();
            $s->setFlash("Email invalide","danger");
            $this->redirect("Formations/details/{$IdFormation}");
            die();
        }


        if($IdMembre)$data["IdMembre"]  = $IdMembre ;
        if($exist || $membre->save($data, true)){
            
            $IdMembre = $IdMembre?$IdMembre:$membre->lastInsert;
            $data = $dataInscrit;
            $data["IdFormation"] = $IdFormation;
            $data["IdMembre"] = $IdMembre;
            if($linkToFormation->save($data, true)){
                $s=Session::loadSession();
                $s->setFlash("Votre demende de participation a bien été enregistrée !!");
                $this->redirect("Formations/details/{$IdFormation}");
                die();
            }
        } 
        $this->redirect("Formations/details/{$IdFormation}");
        die(); 
    }
}

