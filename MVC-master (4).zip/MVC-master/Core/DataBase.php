<?php
//Classe utilitaire gére connexion -tout ce qui est requête sql 
class DataBase {//Connexion à la base de donnée général- singleton patron de conception comme MVC. Instancier une classe une seule fois donc connxion à la base de données une seule fois
    private $db_host = "127.0.0.1:3306";
    private $db_name = "arpp";
    private $db_login = "root";
    private $db_pass = "";
    private $db = null; 

    public static $connection = null;//Connection définit à nul- 

    private function __construct(){//Fonction permettant la connexion à la base de donnée. Elle est utilisé dans la page App
        try{
			$PDO = new PDO(//Driver de base de données soit une extension de base de donnee 
				"mysql:host=".$this->db_host."; dbname=".$this->db_name.";",
				$this->db_login,
				$this->db_pass,
				array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8')//Drvier PDO par défaut est silencieux 
                //(pas de génration d'erreur) forcer la genration d'erreurs ici. Dernier parmetre si l'encodage est donné UFT8
			);
			//$PDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
			$this->db = $PDO;
		}catch(PDOException $e){//Si ytry ne se passe pas comme prévu on le récupère dans le catch comme ça on contrôle en cas d'erreur
            //Récupartion de l'exception et affichage puis arrêt avec un die 
            echo "<pre>";
            print_r($e);
            echo "</pre>";
            die("cant connect to database !!");
		}
    }

    public function prepare($sql=""){ //Prépartion des requêtes 
        return $this->db->prepare($sql);
    }
    public static function getConnection(){//Récuperation de la connexion 
        if (DataBase::$connection !== null) return DataBase::$connection;
        DataBase::$connection = new DataBase();
        return DataBase::$connection; 
    }

    public function lastInsertId(){//Récuperation du ID de la dernière insertion à la base 
        return $this->db->lastInsertId();
    }

    public function query($sql){//Injecter la requête dans l'extension 
        $this->db->query($sql);
    }

}
