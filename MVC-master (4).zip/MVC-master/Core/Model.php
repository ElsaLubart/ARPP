<?php
//MODELE 
Class Model{

    public $db = null;//data base 
    public $table = "formation";//nom de la table souhaité 
    public $list = [];//liste des lignes récupéré 
    public $primaryKey = "id";//nom de la clès primaire de la table 
    public $lastInsert = null;//Identifiant de la dernière ligne inséré dans la table 
    
    public function validate($data){//Validé les données dans le cas d'insertion ou modification 
        foreach($data as $k=>$v){ //Validation Tout les champs sont obligatoire mais pas de contrôle des champs 
            if(is_null($v)) return false;
            $var = trim($v);
            $var = ltrim($var);
            if(!is_numeric($var) && empty($var)){
                echo $var."<br>";
                return false;
            }
        }

        return true;
    }

    function __construct($table, $pkey = "id"){//Constructeur 
        //l'instance de la bd 
        $this->db = DataBase::getConnection();
        $this->table = $table;
        $this->primaryKey = $pkey;
    }

    public function getAll(){//Récupération de toutes les lignes d'une table 
        $sql = "select * from ".$this->table;
        $pre = $this->db->prepare($sql);
		$pre->execute();
		$this->list = $pre->fetchAll(PDO::FETCH_OBJ);
    }

    public function getOneById($id = "1"){//Lecture par clès primaire 
        $sql = "select * from {$this->table} where {$this->primaryKey} = {$id}";
        $pre = $this->db->prepare($sql);
		$pre->execute();
        $this->list = $pre->fetchAll(PDO::FETCH_OBJ);
    }

	function save($data, $inscription=false){//Mise à jour et insertion. Si les donnee varaible data, 
        //si parmit les par on trouve clés primaire il ya auto modification sinon insertion 
        // nom = elsa ; prenom = lorem 
        /*echo "<pre>";
        print_r($data);
        echo "</pre>";*/
        $s = Session::loadSession(); //Connexion admin mais pas nécessaire (le controle est externalisé) 
        
        if(!$this->validate($data)){//Validation des données  
            $s->setFlash("Merci de vérifier que les champs sont bien rempli", "danger");
            return false;
        }
        //PREPARATION DE LA REQUETE 
		$key = $this->primaryKey; 
		$fields = array();
		$w = array();
		foreach($data as $k => $v){//Pacourir les collections et donne la possibilité 
            //d'acceder à chaque iteration un couple clés valeur. Comment une ligne doit être persister dans la db. 
            //REformater les donnees pour génere une chaîne de caractère 
            if($k != $key){ 
                $fields[] = "$k=:$k";//Préparation des champs 
                $w[":$k"] = $v;//Prepartaion de l arequête 
            }elseif(!empty($v)){//Si non vde injection des valeurs 
                $w[":$k"] = $v;
            }
		}
		if(!isset($data[$key])){//Requête inserer 
			$sql = "INSERT INTO ".$this->table." SET ".implode(',',$fields);
		}else{
            $sql = "UPDATE ".$this->table." SET ".implode(',',$fields)." WHERE ".$key."=:".$key;//Requête modifier 
        }
		if(isset($sql)){
             
			$pre = $this->db->prepare($sql);//Preparation de la requête 
			$pre->execute($w);//Execution de la requête 
            if(!isset($data->$key)){//Test seulement si  pas clès primaire 
                $this->lastInsert = $this->db->lastInsertId();
                //la dernière insertion Une fois les valeurs inséere on récupère 
            }
			return true;
		}
		
		return false;
	}
	
	function delete($id){//suppression par ID 
        $s = Session::loadSession();
        if(!$s->loginVerification())return;
		$sql = "DELETE FROM {$this->table} WHERE {$this->primaryKey} = $id";//requête 
		$this->db->query($sql);
	}

    public function exec($sql, $type = true){//Exécuter pour n'importe quel type de requête si nécessaire de jointure 
        //Requête plus compliquée 
        $select = explode(" ", $sql);//Prépare 
        if(count($select) === 0 || strtolower($select[0])!=="select"){//Requête contient le mot clès select on éxecute si non on fait rien
            $s = Session::loadSession();
            if(!$s->loginVerification())return;
        }
        if(isset($sql)){//Exécution de la requête 
			$pre = $this->db->prepare($sql);
			$pre->execute();
            if($type) $this->list = $pre->fetchAll(PDO::FETCH_OBJ);
            else $this->lastInsert = $this->db->lastInsertId();
			return true;
		}
		return false;
    }

}