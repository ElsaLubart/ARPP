<?php
class Session{ //Gere l'authentification et gere les messages d'erreurs car ils sont censé être renvoyé à l'utilisateurs
	
    var $hasMessge = false;
    public static $s = null;
	private function __construct(){
		if(!isset($_SESSION))
			session_start();
	}

    public static function loadSession(){//Fonction permettant d'ouvrir la session en faisant appelle à la classe session (création d'une nouvelle session) 
        return Session::$s ? Session::$s : new Session();
    }

	function set($key, $value = null){ //Ajouter une valeur ou clès dans la session  
		if(!is_array($key)){
			$_SESSION[$key] = $value;
		}else{
			foreach($key as $k => $v){
				$_SESSION[$k] = $v;
			}
		}
	}
	
	function get($key){//Fonction pour récupérer une valeur à travers la  la clé de la session 
		if(!is_array($key)){
			return $_SESSION[$key];
		}else{
			$d = array();
			foreach($key as $k){//Pour chaque clé tel que variable k 
				$d[$k] = $_SESSION[$k];//Associé la session k 
			}
			return $d;
		}
	}
	
	function setLoginSession($data){//Définit la session login 
        $_SESSION = array();
		$this->set($data);
		$hash = array();
		foreach($data as $k => $v){
			$hash[]= $v;
		}
		$hash = implode('-',$hash); 
        $hash = sha1($hash);
		$this->set('hash',$hash);
	}
	
	function disconnect(){//Déconnexion fonction 
		foreach($_SESSION as $k=>$v){//Pour chaque session 
			$this->set($k,"");
		}
		session_destroy();//destruction de la session
	}
	
	function exist($key){//Verification que la d=fonction existe 
		if(isset($_SESSION[$key]))
			return !empty($_SESSION[$key]);
		return false;
	}
	
	function loginVerification(){//Verification du login pour l'admin 

		if($this->exist('hash')){//si le login existe 
			$hash = array();//tableau insertion 
			foreach($_SESSION as $k =>$v){//Boucle pour chaque session 
				if($k != 'hash' && $k != 'flash')//Si il ,n' y a  pas un message d'erreur 
					$hash[] = $v;
			}
			$hash = implode('-',$hash); //implode : Retourne une chaîne contenant la représentation en chaîne de caractères de tous les éléments du tableau array, dans le même ordre, avec la chaîne separator, placée entre deux éléments.
            $hash = sha1($hash);//retourne chaîne de caractère 
			if($hash == $this->get('hash'))//si la variable hash est égal a
				return true;//retourne valeur vrai 
		}
		return false;//sinon retourne valeur FAUX 
	}
	
	function setFlash($msg, $type = "success"){//fonction définissant les message d'erreurs ou tout ce passe bien message, utilisation de la fonction flash 
        $this->hasMessge = $type === "danger" ? true: false;
		$_SESSION['flash'] = array(
			'message' =>$msg,
			'type' =>$type
		);
	}
	
	function flash($clear = false){//Fonction pour faire apparaitre les message d'erreur définit 
		if(!$this->exist('flash'))
			return ;
		$flash = '<div class="alert alert-'.$this->get('flash')['type'].'">'.$this->get('flash')['message'].'</div>';
		if($clear){
			$flash = '<section style="width:100%;position:absolute;top:-40;z-index:999"><div class="alert alert-'.$this->get('flash')['type'].'">'.$this->get('flash')['message'].'</div></section>';
			$this->set('flash');
		} 
		return $flash;
	}	
}
?>