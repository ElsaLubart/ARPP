<?php

class Url {

    static function getUrl($url = "Base/index"){//Récupération de l'URL; conacatenation entre url souhaité avec la base  
        echo Url::link($url);
    }

    static function link ($url = "Base/index"){//Gére les Liens 
        return BU."/".$url;
    }

}