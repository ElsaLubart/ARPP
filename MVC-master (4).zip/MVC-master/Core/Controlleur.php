<?php 
//CONTROLLEUR CORPS DE L'APPLICATION Réalise les différerent traitements, les différents controlleurs sont des filles de cette classe   
class Controlleur {
    //Un constructeur permet d'initialiser les propriétéS 'un dobjet PENDANT LA CTR2ATION DE L4OBJE; On appelle automatiquement la fonction request lorsque on crée un objet à partir de cette classe. Il évite d'appeler la méthode set_name() qui réduit donc le code: 
    var $request;
    var $model;//Appelle la classe modèle (liaison) référence du modèle dans la classe du controlleur. 
    function __construct($request){//Constructeur de la classe
        $this->request = $request;
    }

     public function render ($vars = null){//Laison entre le controlleur et la vue traduit par render. Récupération d'une vue 
         if($vars) 
            extract($vars);//La fonction extract() permet d'importer la variable var défini par défaut sur nulle 

         // génére le chemin physique de la vue à rendre. Regroupement des vues qui prennent le nom du controlleur
         $view = VIEW.DS.$this->request->controlleur.DS.$this->request->action.".php"; //Le nom du controlleur concaténer par un separateur de repetoire concatenoer avec le nom de l'action 
         
         $layout = VIEW.DS."layout.php";//Chemin physique pour le layout page statique css
         $data = $this->model;//Réferencer le modèle affectation direct
         $s = Session::loadSession();//Récuperation de la session (connecté ou non) 

         $___Render_Curent_View = "";//Déclaration var vide
         
         if (file_exists($view)){//test fichier existe ou non 
            ob_start();//Initialiser un espace mémoire pour stocqué la page récupérer juste après 
            require_once $view ;//Récupère la vue 
            $___Render_Curent_View = ob_get_clean(); //Injecte ce qu'on a stocké dans l'espace mémoire dans la variable 
           
            require_once $layout ; //Récupère le layout

        }else{
            echo " fichier n'existe pas "; //Si on ne trouve pas la vue on génere une erreur de type fichier n'existe pas 
        }
     }

     function redirect($url, $code = null){ //Méthode de redirection appeler pour rediriger vers un lien 
		if($code == 301){//Me code 301 rediriger de manière permanente vers le lien - boucle d'appel 
			header("HTTP/1.1 301 Moved Permanently");
		}
                    
        
		header("location:http://127.0.0.1:8080".Url::link($url));//Redirection vers un lien 
        die();

	}

    protected function validateFileToUpload($file){//Validation du fichier à télecharger- fonction gère seulement le contrôle - car utilisation du telechargement fichier partout
        extract($file);
        $nameParts = explode(".",$name);
        $fileExt = strtolower(end($nameParts));
        $allorwedFiles = array('pdf');//contrôle type de fichier
        $path = null;
        if(in_array($fileExt,$allorwedFiles) && $error === 0 && $size <= 600000){//Contrôle sur la taille et le déroulement de l'upload 
            $uniqueName = uniqid('',true).".{$fileExt}";
            $path = array();
            $path["name"] = $name;
            $path["from"] =  $tmp_name;
            $path["to"] = $nameParts[0]."_".$uniqueName;
        }
        return $path;
    }
}
?>